package com.akash.PPMTool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PpmToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
